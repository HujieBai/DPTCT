#include <RcppEigen.h>
//[[Rcpp::depends(RcppEigen)]]
using namespace Eigen;
using namespace std;
using namespace Rcpp;

// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp 
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
//

// [[Rcpp::export]]
List edt_c_1(double &gamma1,Eigen::VectorXd &q, Eigen::MatrixXd &yitx,
             Eigen::MatrixXd &xx, int &tt, int &nn) {
  int nx,t;
  nx = xx.cols();
  Eigen::MatrixXd delty1p1(tt-2,nn),delty1p(tt-1,nn), yte(tt-1,nn),zsx(1,nx)
    ,deltxp(tt-1,nx),yte1(tt-2,nn),regime2(tt*nn,1),regime2x(tt*nn,1),zs(1,nn),
    xxte(tt,nx),xxte1(tt-1,nx);
  
  delty1p1 = Eigen::MatrixXd::Zero(tt-2,nn);
  deltxp = Eigen::MatrixXd::Zero(tt-2,nx);
  regime2 = Eigen::MatrixXd::Zero(tt*nn,1);
  zs = Eigen::MatrixXd::Zero(1,nn);
  zsx = Eigen::MatrixXd::Zero(1,nx);
  
  for(t=0;t<tt*nn;t++){
    if(q(t)>gamma1){
      regime2(t,0)=1;
    }
  }
  regime2x = regime2;
  regime2.resize(tt,nn);
  regime2x.resize(tt,nx);
  regime2 = regime2.bottomRows(tt-1).eval();
  
  yitx = yitx.topRows(tt-1).eval();
  
  yte = (yitx.array()*regime2.array()).eval();
  yte1 = yte.bottomRows(tt-2).eval();
  yte = yte.topRows(tt-2).eval();
  delty1p1 = yte1 - yte;
  delty1p << zs,
             delty1p1;
  delty1p.resize((tt-1)*nn,1);
  
  xxte = xx.array()*regime2x.array();
  
  xxte1 = xxte.bottomRows(tt-1).eval();
  xxte = xxte.topRows(tt-1).eval();
  
  deltxp = xxte1 - xxte;
  deltxp.row(0) = zsx.row(0);
  deltxp.resize((tt-1)*nn,nx/nn);
  return List::create(_["delty1p"] = delty1p,_["deltxp"] = deltxp);
}

// [[Rcpp::export]]
List tr_c_1(Eigen::MatrixXd &deltxi1,Eigen::MatrixXd &delty0,Eigen::MatrixXd &delty1s,
                       Eigen::MatrixXd &deltxs,Eigen::MatrixXd &delty1p,Eigen::MatrixXd &deltxp,
                       Eigen::MatrixXd &deltcvi1,Eigen::MatrixXd &deltcvs,
                       Eigen::MatrixXd &ininxc,Eigen::MatrixXd &omega,Eigen::MatrixXd &faz,
                       Eigen::VectorXd &delts,int &tt, int &nn,double &xy1) {
  
  int nx,nz,t;
  nx = deltxi1.cols();
  nz = deltcvi1.cols();
  Eigen::MatrixXd dy0((tt-1)*nn,1),y0iv(tt-3,nn),sy1((tt-1)*nn,1),sx1((tt-1)*nn,nx),
  py1((tt-1)*nn,1),px1((tt-1)*nn,nx),z1(((tt-1)*nn),nz),y1iv((tt-3),(2+2*nx+nz)*nn),
  y2iv((tt-3),(2+2*nx+nz)*nn),xx0((tt-2),(2+2*nx+nz)*nn),xx1((tt-1),(2+2*nx+nz)*nn)
    ,yy0((tt-2),nn),xxc((tt-1)*nn,(3+3*nx+nz)),fit2((tt-2)*nn,1),omega1(tt-1,tt-1),
    initres((tt-1)*nn,1),xnn(tt-1,1),uv(1,1),wv(1,1);
  
  dy0.col(0) = delty0.col(0);
  dy0.resize(tt-1,nn);
  
  y0iv = dy0.bottomRows(tt-3);
  y0iv.resize((tt-3)*nn,1);
  
  sy1 = delty1s;
  sx1 = deltxs;
  py1 = delty1p;
  px1 = deltxp;
  z1 = deltcvs;
  sy1.resize(tt-1,nn);
  sx1.resize(tt-1,nx*nn);
  py1.resize(tt-1,nn);
  px1.resize(tt-1,nx*nn);
  z1.resize(tt-1,nz*nn);
  
  Eigen::MatrixXd sy12 = sy1.middleRows(1,tt-3).eval();
  Eigen::MatrixXd sx12 = sx1.bottomRows(tt-3).eval();
  Eigen::MatrixXd py12 = py1.middleRows(1,tt-3).eval();
  Eigen::MatrixXd px12 = px1.bottomRows(tt-3).eval();
  Eigen::MatrixXd z12 = z1.bottomRows(tt-3).eval();
   
   
  Eigen::MatrixXd sy13 = sy1.topRows(tt-3).eval();
  Eigen::MatrixXd py13 = py1.topRows(tt-3).eval();
  
  y1iv << sy12,sx12,py12,px12,z12;
  y2iv << sy13,sx12,py13,px12,z12;
  y1iv.resize((tt-3)*nn,(2+2*nx+nz));
  y2iv.resize((tt-3)*nn,(2+2*nx+nz));
  
  xx1 = Eigen::MatrixXd::Zero((tt-1)*nn,(2+2*nx+nz));
  xx1 << delty1s,deltxs,delty1p,deltxp,deltcvs;
  xxc = Eigen::MatrixXd::Zero((tt-1)*nn,(3+3*nx+2*nz));
  xxc << delty1s,deltxs,delty1p,deltxp,deltcvs,ininxc;
  
  xx1.resize(tt-1,nn*(2+2*nx+nz));
  xx0 = xx1.bottomRows(tt-2);
  xx0.resize((tt-2)*nn,(2+2*nx+nz));
  yy0 = dy0.bottomRows(tt-2);
  yy0.resize((tt-2)*nn,1);
  
  Eigen::MatrixXd betas = (y2iv.adjoint()*y1iv).inverse()*(y2iv.adjoint()*y0iv);
  
  Eigen::VectorXd betas0 = betas.col(0);
  
  Eigen::VectorXd pars0(3+3*nx+2*nz),pars1(5+3*nx+2*nz);
  pars0 << betas0,delts;
  Eigen::MatrixXd betas1(3+3*nx+2*nz,1);
  betas1.col(0) = pars0;
  fit2 = (yy0 - xx0*betas).array().square();
  
  double sigmau0,w0,sigmau,wg;
  sigmau0 = (fit2.sum())/(2*nn*(tt-3));
  w0 = xy1/((nn-tt)*sigmau0);
  
  omega1 = omega;
  omega1(0,0) = w0;
  Eigen::MatrixXd omega2 = omega1.inverse();
  
  dy0.resize((tt-1)*nn,1);
  initres = (dy0 - xxc*betas1);
  
  sigmau = 0;
  wg = 0;
  
  for(t=0;t<nn;t++){
    xnn = initres.middleRows(t*(tt-1),tt-1);
    uv = xnn.adjoint()*omega2*xnn;
    sigmau += uv(0,0);
    wv = xnn.adjoint()*faz*xnn;
    wg += wv(0,0);
  }
  
  sigmau = sigmau/(nn*(tt-1));
  double tn;
  tn = tt;
  
  wg = (tn-2)/(tn-1) + wg/(sigmau*nn*(pow(tt-1,2)));

 if(sigmau<0){
   sigmau = -sigmau;
  }
  
  if(wg<= (tt-2)/(tt-1)){
    wg += (tt-2)/(tt-1);
  }
  
  sigmau= pow(sigmau,0.5);
  
  pars1 << betas0,delts,sigmau,wg;

  return List::create(_["pars1"] = pars1,_["xxc"] = xxc);
}

// [[Rcpp::export]]
List tr_c_x1(Eigen::MatrixXd &deltxi1,Eigen::MatrixXd &delty0,Eigen::MatrixXd &delty1s,
            Eigen::MatrixXd &deltxs,Eigen::MatrixXd &delty1p,Eigen::MatrixXd &deltxp,
            Eigen::MatrixXd &deltcvi1,Eigen::MatrixXd &deltcvs,
            Eigen::MatrixXd &ininxc,Eigen::MatrixXd &omega,Eigen::MatrixXd &faz,
            Eigen::VectorXd &delts,int &tt, int &nn,double &xy1) {
  
  int nx,nz,t,ny,nxx;
  nx = deltxi1.cols();
  nxx = deltxp.cols();
  nz = deltcvi1.cols();
  ny = delty1p.cols();
  Eigen::MatrixXd dy0((tt-1)*nn,1),y0iv(tt-3,nn),sy1((tt-1)*nn,1),sx1((tt-1)*nn,nx),
  py1((tt-1)*nn,ny),px1((tt-1)*nn,nxx),z1(((tt-1)*nn),nz),y1iv((tt-3),(1+ny+nx+nxx+nz)*nn),
  y2iv((tt-3),(1+ny+nx+nxx+nz)*nn),xx0((tt-2),(1+ny+nx+nxx+nz)*nn),xx1((tt-1),(1+ny+nx+nxx+nz)*nn)
    ,yy0((tt-2),nn),xxc((tt-1)*nn,(2+ny+2*nx+nxx+2*nz)),fit2((tt-2)*nn,1),omega1(tt-1,tt-1),
    initres((tt-1)*nn,1),xnn(tt-1,1),uv(1,1),wv(1,1);
  
  dy0.col(0) = delty0.col(0);
  dy0.resize(tt-1,nn);
  
  y0iv = dy0.bottomRows(tt-3);
  y0iv.resize((tt-3)*nn,1);
  
  sy1 = delty1s;
  sx1 = deltxs;
  py1 = delty1p;
  px1 = deltxp;
  z1 = deltcvs;
  sy1.resize(tt-1,nn);
  sx1.resize(tt-1,nx*nn);
  py1.resize(tt-1,nn*ny);
  px1.resize(tt-1,nxx*nn);
  z1.resize(tt-1,nz*nn);
  
  Eigen::MatrixXd sy12 = sy1.middleRows(1,tt-3).eval();
  Eigen::MatrixXd sx12 = sx1.bottomRows(tt-3).eval();
  Eigen::MatrixXd py12 = py1.middleRows(1,tt-3).eval();
  Eigen::MatrixXd px12 = px1.bottomRows(tt-3).eval();
  Eigen::MatrixXd z12 = z1.bottomRows(tt-3).eval();
  
  
  Eigen::MatrixXd sy13 = sy1.topRows(tt-3).eval();
  Eigen::MatrixXd py13 = py1.topRows(tt-3).eval();
  
  y1iv << sy12,sx12,py12,px12,z12;
  y2iv << sy13,sx12,py13,px12,z12;
  y1iv.resize((tt-3)*nn,(1+ny+nx+nxx+nz));
  y2iv.resize((tt-3)*nn,(1+ny+nx+nxx+nz));
  
  xx1 = Eigen::MatrixXd::Zero((tt-1)*nn,(1+ny+nx+nxx+nz));
  xx1 << delty1s,deltxs,delty1p,deltxp,deltcvs;
  xxc = Eigen::MatrixXd::Zero((tt-1)*nn,(2+ny+2*nx+nxx+2*nz));
  xxc << delty1s,deltxs,delty1p,deltxp,deltcvs,ininxc;
  
  xx1.resize(tt-1,nn*(1+ny+nx+nxx+nz));
  xx0 = xx1.bottomRows(tt-2);
  xx0.resize((tt-2)*nn,(1+ny+nx+nxx+nz));
  yy0 = dy0.bottomRows(tt-2);
  yy0.resize((tt-2)*nn,1);
  
  Eigen::MatrixXd betas = (y2iv.adjoint()*y1iv).inverse()*(y2iv.adjoint()*y0iv);
  
  Eigen::VectorXd betas0 = betas.col(0);
  
  Eigen::VectorXd pars0((2+ny+2*nx+nxx+2*nz)),pars1((4+ny+2*nx+nxx+2*nz));
  pars0 << betas0,delts;
  Eigen::MatrixXd betas1((2+ny+2*nx+nxx+2*nz),1);
  betas1.col(0) = pars0;
  fit2 = (yy0 - xx0*betas).array().square();
  
  double sigmau0,w0,sigmau,wg;
  sigmau0 = (fit2.sum())/(2*nn*(tt-3));
  w0 = xy1/((nn-tt)*sigmau0);
  
  omega1 = omega;
  omega1(0,0) = w0;
  Eigen::MatrixXd omega2 = omega1.inverse();
  
  dy0.resize((tt-1)*nn,1);
  initres = (dy0 - xxc*betas1);
  
  sigmau = 0;
  wg = 0;
  
  for(t=0;t<nn;t++){
    xnn = initres.middleRows(t*(tt-1),tt-1);
    uv = xnn.adjoint()*omega2*xnn;
    sigmau += uv(0,0);
    wv = xnn.adjoint()*faz*xnn;
    wg += wv(0,0);
  }
  
  sigmau = sigmau/(nn*(tt-1));
  double tn;
  tn = tt;
  
  wg = (tn-2)/(tn-1) + wg/(sigmau*nn*(pow(tt-1,2)));
  
  if(sigmau<0){
    sigmau = -sigmau;
  }
  
  if(wg<= (tt-2)/(tt-1)){
    wg += (tt-2)/(tt-1);
  }
  
  sigmau= pow(sigmau,0.5);
  
  pars1 << betas0,delts,sigmau,wg;
  
  return List::create(_["pars1"] = pars1,_["xxc"] = xxc);
}

// [[Rcpp::export]]
List tr_c_2(Eigen::MatrixXd &deltxi1,Eigen::MatrixXd &delty0,Eigen::MatrixXd &delty1s,
            Eigen::MatrixXd &deltxs,
            Eigen::MatrixXd &deltcvi1,Eigen::MatrixXd &deltcvs,
            Eigen::MatrixXd &ininxc,Eigen::MatrixXd &omega,Eigen::MatrixXd &faz,
            Eigen::VectorXd &delts,int &tt, int &nn,double &xy1) {
  
  int nx,nz,t;
  nx = deltxi1.cols();
  nz = deltcvi1.cols();
  Eigen::MatrixXd dy0((tt-1)*nn,1),y0iv(tt-3,nn),sy1((tt-1)*nn,1),sx1((tt-1)*nn,nx),
  z1(((tt-1)*nn),nz),y1iv((tt-3),(1+1*nx+nz)*nn),
  y2iv((tt-3),(1+1*nx+nz)*nn),xx0((tt-2),(1+1*nx+nz)*nn),xx1((tt-1),(1+1*nx+nz)*nn)
    ,yy0((tt-2),nn),xxc((tt-1)*nn,(2+2*nx+nz)),fit2((tt-2)*nn,1),omega1(tt-1,tt-1),
    initres((tt-1)*nn,1),xnn(tt-1,1),uv(1,1),wv(1,1);
  
  dy0.col(0) = delty0.col(0);
  dy0.resize(tt-1,nn);
  
  y0iv = dy0.bottomRows(tt-3);
  y0iv.resize((tt-3)*nn,1);
  
  sy1 = delty1s;
  sx1 = deltxs;
  z1 = deltcvs;
  sy1.resize(tt-1,nn);
  sx1.resize(tt-1,nx*nn);
  z1.resize(tt-1,nz*nn);
  
  Eigen::MatrixXd sy12 = sy1.middleRows(1,tt-3).eval();
  Eigen::MatrixXd sx12 = sx1.bottomRows(tt-3).eval();
  Eigen::MatrixXd z12 = z1.bottomRows(tt-3).eval();
  
  
  Eigen::MatrixXd sy13 = sy1.topRows(tt-3).eval();
  
  y1iv << sy12,sx12,z12;
  y2iv << sy13,sx12,z12;
  y1iv.resize((tt-3)*nn,(1+1*nx+nz));
  y2iv.resize((tt-3)*nn,(1+1*nx+nz));
  
  xx1 = Eigen::MatrixXd::Zero((tt-1)*nn,(1+1*nx+nz));
  xx1 << delty1s,deltxs,deltcvs;
  xxc = Eigen::MatrixXd::Zero((tt-1)*nn,(2+2*nx+2*nz));
  xxc << delty1s,deltxs,deltcvs,ininxc;
  
  xx1.resize(tt-1,nn*(1+1*nx+nz));
  xx0 = xx1.bottomRows(tt-2);
  xx0.resize((tt-2)*nn,(1+1*nx+nz));
  yy0 = dy0.bottomRows(tt-2);
  yy0.resize((tt-2)*nn,1);
  
  Eigen::MatrixXd betas = (y2iv.adjoint()*y1iv).inverse()*(y2iv.adjoint()*y0iv);
  
  Eigen::VectorXd betas0 = betas.col(0);
  
  Eigen::VectorXd pars0(2+2*nx+2*nz),pars1(4+2*nx+2*nz);
  pars0 << betas0,delts;
  Eigen::MatrixXd betas1(2+2*nx+2*nz,1);
  betas1.col(0) = pars0;
  fit2 = (yy0 - xx0*betas).array().square();
  
  double sigmau0,w0,sigmau,wg;
  sigmau0 = (fit2.sum())/(2*nn*(tt-3));
  w0 = xy1/((nn-tt)*sigmau0);
  
  omega1 = omega;
  omega1(0,0) = w0;
  Eigen::MatrixXd omega2 = omega1.inverse();
  
  dy0.resize((tt-1)*nn,1);
  initres = (dy0 - xxc*betas1);
  
  sigmau = 0;
  wg = 0;
  
  for(t=0;t<nn;t++){
    xnn = initres.middleRows(t*(tt-1),tt-1);
    uv = xnn.adjoint()*omega2*xnn;
    sigmau += uv(0,0);
    wv = xnn.adjoint()*faz*xnn;
    wg += wv(0,0);
  }
  
  sigmau = sigmau/(nn*(tt-1));
  double tn;
  tn = tt;
  
  wg = (tn-2)/(tn-1) + wg/(sigmau*nn*(pow(tt-1,2)));
  
  if(sigmau<0){
    sigmau = -sigmau;
  }
  
  if(wg<= (tt-2)/(tt-1)){
    wg += (tt-2)/(tt-1);
  }
  
  sigmau= pow(sigmau,0.5);
  
  pars1 << betas0,delts,sigmau,wg;
  
  return List::create(_["pars1"] = pars1,_["xxc"] = xxc);
}
// [[Rcpp::export]]
List tr_c_2x(Eigen::MatrixXd &deltxi1,Eigen::MatrixXd &delty0,Eigen::MatrixXd &delty1s,
            Eigen::MatrixXd &deltxs,
            Eigen::MatrixXd &deltcvi1,Eigen::MatrixXd &deltcvs,
            Eigen::MatrixXd &ininxc,Eigen::MatrixXd &omega,Eigen::MatrixXd &faz,
            Eigen::VectorXd &delts,int &tt, int &nn,double &xy1) {
  
  int nx,nz,t,nx1;
  nx1 = deltxi1.cols();
  nz = deltcvi1.cols();
  nx = deltxs.cols();
  Eigen::MatrixXd dy0((tt-1)*nn,1),y0iv(tt-3,nn),sy1((tt-1)*nn,1),sx1((tt-1)*nn,nx),
  z1(((tt-1)*nn),nz),y1iv((tt-3),(1+1*nx+nz)*nn),
  y2iv((tt-3),(1+1*nx+nz)*nn),xx0((tt-2),(1+1*nx+nz)*nn),xx1((tt-1),(1+1*nx+nz)*nn)
    ,yy0((tt-2),nn),xxc((tt-1)*nn,(2+nx+2*nz+nx1)),fit2((tt-2)*nn,1),omega1(tt-1,tt-1),
    initres((tt-1)*nn,1),xnn(tt-1,1),uv(1,1),wv(1,1);
  
  dy0.col(0) = delty0.col(0);
  dy0.resize(tt-1,nn);
  
  y0iv = dy0.bottomRows(tt-3);
  y0iv.resize((tt-3)*nn,1);
  
  sy1 = delty1s;
  sx1 = deltxs;
  z1 = deltcvs;
  sy1.resize(tt-1,nn);
  sx1.resize(tt-1,nx*nn);
  z1.resize(tt-1,nz*nn);
  
  Eigen::MatrixXd sy12 = sy1.middleRows(1,tt-3).eval();
  Eigen::MatrixXd sx12 = sx1.bottomRows(tt-3).eval();
  Eigen::MatrixXd z12 = z1.bottomRows(tt-3).eval();
  
  
  Eigen::MatrixXd sy13 = sy1.topRows(tt-3).eval();
  
  y1iv << sy12,sx12,z12;
  y2iv << sy13,sx12,z12;
  y1iv.resize((tt-3)*nn,(1+1*nx+nz));
  y2iv.resize((tt-3)*nn,(1+1*nx+nz));
  
  xx1 = Eigen::MatrixXd::Zero((tt-1)*nn,(1+1*nx+nz));
  xx1 << delty1s,deltxs,deltcvs;
  xxc = Eigen::MatrixXd::Zero((tt-1)*nn,(2+nx+2*nz+nx1));
  xxc << delty1s,deltxs,deltcvs,ininxc;
  
  xx1.resize(tt-1,nn*(1+1*nx+nz));
  xx0 = xx1.bottomRows(tt-2);
  xx0.resize((tt-2)*nn,(1+1*nx+nz));
  yy0 = dy0.bottomRows(tt-2);
  yy0.resize((tt-2)*nn,1);
  
  Eigen::MatrixXd betas = (y2iv.adjoint()*y1iv).inverse()*(y2iv.adjoint()*y0iv);
  
  Eigen::VectorXd betas0 = betas.col(0);
  
  Eigen::VectorXd pars0(2+nx+2*nz+nx1),pars1(4+nx+2*nz+nx1);
  pars0 << betas0,delts;
  Eigen::MatrixXd betas1(2+nx+2*nz+nx1,1);
  betas1.col(0) = pars0;
  fit2 = (yy0 - xx0*betas).array().square();
  
  double sigmau0,w0,sigmau,wg;
  sigmau0 = (fit2.sum())/(2*nn*(tt-3));
  w0 = xy1/((nn-tt)*sigmau0);
  
  omega1 = omega;
  omega1(0,0) = w0;
  Eigen::MatrixXd omega2 = omega1.inverse();
  
  dy0.resize((tt-1)*nn,1);
  initres = (dy0 - xxc*betas1);
  
  sigmau = 0;
  wg = 0;
  
  for(t=0;t<nn;t++){
    xnn = initres.middleRows(t*(tt-1),tt-1);
    uv = xnn.adjoint()*omega2*xnn;
    sigmau += uv(0,0);
    wv = xnn.adjoint()*faz*xnn;
    wg += wv(0,0);
  }
  
  sigmau = sigmau/(nn*(tt-1));
  double tn;
  tn = tt;
  
  wg = (tn-2)/(tn-1) + wg/(sigmau*nn*(pow(tt-1,2)));
  
  if(sigmau<0){
    sigmau = -sigmau;
  }
  
  if(wg<= (tt-2)/(tt-1)){
    wg += (tt-2)/(tt-1);
  }
  
  sigmau= pow(sigmau,0.5);
  
  pars1 << betas0,delts,sigmau,wg;
  
  return List::create(_["pars1"] = pars1,_["xxc"] = xxc);
}

// [[Rcpp::export]]
List tr_c_3x(Eigen::MatrixXd &deltxi1,Eigen::MatrixXd &delty0,Eigen::MatrixXd &delty1s,
             Eigen::MatrixXd &deltxs,
             Eigen::MatrixXd &deltcvi1,Eigen::MatrixXd &deltcvs,
             Eigen::MatrixXd &ininxc,Eigen::MatrixXd &omega,Eigen::MatrixXd &faz,
             Eigen::VectorXd &delts,int &tt, int &nn) {
  
  int nx,nz,t,nx1;
  nx1 = deltxi1.cols();
  nz = deltcvi1.cols();
  nx = deltxs.cols();
  Eigen::MatrixXd dy0((tt-1)*nn,1),y0iv(tt-3,nn),sy1((tt-1)*nn,1),sx1((tt-1)*nn,nx),
  z1(((tt-1)*nn),nz),y1iv((tt-3),(1+1*nx+nz)*nn),
  y2iv((tt-3),(1+1*nx+nz)*nn),xx0((tt-2),(1+1*nx+nz)*nn),xx1((tt-1),(1+1*nx+nz)*nn)
    ,yy0((tt-2),nn),xxc((tt-1)*nn,(2+nx+2*nz+nx1)),fit2((tt-2)*nn,1),omega1(tt-1,tt-1),
    initres((tt-1)*nn,1),xnn(tt-1,1),uv(1,1),wv(1,1);
  
  dy0.col(0) = delty0.col(0);
  dy0.resize(tt-1,nn);
  
  y0iv = dy0.bottomRows(tt-3);
  y0iv.resize((tt-3)*nn,1);
  
  sy1 = delty1s;
  sx1 = deltxs;
  z1 = deltcvs;
  sy1.resize(tt-1,nn);
  sx1.resize(tt-1,nx*nn);
  z1.resize(tt-1,nz*nn);
  
  Eigen::MatrixXd sy12 = sy1.middleRows(1,tt-3).eval();
  Eigen::MatrixXd sx12 = sx1.bottomRows(tt-3).eval();
  Eigen::MatrixXd z12 = z1.bottomRows(tt-3).eval();
  
  
  Eigen::MatrixXd sy13 = sy1.topRows(tt-3).eval();
  
  y1iv << sy12,sx12,z12;
  y2iv << sy13,sx12,z12;
  y1iv.resize((tt-3)*nn,(1+1*nx+nz));
  y2iv.resize((tt-3)*nn,(1+1*nx+nz));
  
  xx1 = Eigen::MatrixXd::Zero((tt-1)*nn,(1+1*nx+nz));
  xx1 << delty1s,deltxs,deltcvs;
  xxc = Eigen::MatrixXd::Zero((tt-1)*nn,(2+nx+2*nz+nx1));
  xxc << delty1s,deltxs,deltcvs,ininxc;
  
  xx1.resize(tt-1,nn*(1+1*nx+nz));
  xx0 = xx1.bottomRows(tt-2);
  xx0.resize((tt-2)*nn,(1+1*nx+nz));
  yy0 = dy0.bottomRows(tt-2);
  yy0.resize((tt-2)*nn,1);
  
  Eigen::MatrixXd betas = (y2iv.adjoint()*y1iv).inverse()*(y2iv.adjoint()*y0iv);
  
  Eigen::VectorXd betas0 = betas.col(0);
  
  Eigen::VectorXd pars0(2+nx+2*nz+nx1),pars1(4+nx+2*nz+nx1);
  pars0 << betas0,delts;
  Eigen::MatrixXd betas1(2+nx+2*nz+nx1,1);
  betas1.col(0) = pars0;
  fit2 = (yy0 - xx0*betas).array().square();
  
  double sigmau0,w0,sigmau,wg;
  w0 = 2;
  
  omega1 = omega;
  omega1(0,0) = w0;
  Eigen::MatrixXd omega2 = omega1.inverse();
  
  dy0.resize((tt-1)*nn,1);
  initres = (dy0 - xxc*betas1);
  
  sigmau = 0;
  wg = 0;
  
  for(t=0;t<nn;t++){
    xnn = initres.middleRows(t*(tt-1),tt-1);
    uv = xnn.adjoint()*omega2*xnn;
    sigmau += uv(0,0);
    wv = xnn.adjoint()*faz*xnn;
    wg += wv(0,0);
  }
  
  sigmau = sigmau/(nn*(tt-1));
  double tn;
  tn = tt;
  
  wg = (tn-2)/(tn-1) + wg/(sigmau*nn*(pow(tt-1,2)));
  
  if(sigmau<0){
    sigmau = -sigmau;
  }
  
  if(wg<= (tt-2)/(tt-1)){
    wg = 1;
  }
  
  
  pars1 << betas0,delts,sigmau,wg;
  
  return List::create(_["pars1"] = pars1,_["xxc"] = xxc);
}

// [[Rcpp::export]]
List tr_c_4x(Eigen::MatrixXd &delty0, Eigen::MatrixXd &deltxs,
             Eigen::MatrixXd &ininxc,Eigen::MatrixXd &omega,Eigen::MatrixXd &faz,
             Eigen::VectorXd &delts,int &tt, int &nn) {
  
  int nx,t,nx1;
  nx1 = ininxc.cols();
  nx = deltxs.cols();
  Eigen::MatrixXd dy0((tt-1)*nn,1),y0iv(tt-3,nn),sy1((tt-1)*nn,1),sx1((tt-1)*nn,nx),
  y1iv((tt-3),(nx)*nn),
  y2iv((tt-3),(nx)*nn),xx1((tt-1),(nx)*nn)
    ,xxc((tt-1)*nn,(nx+nx1)),omega1(tt-1,tt-1),
    initres((tt-1)*nn,1),xnn(tt-1,1),uv(1,1),wv(1,1);
  
  dy0.col(0) = delty0.col(0);
  dy0.resize(tt-1,nn);
  
  y0iv = dy0.bottomRows(tt-3);
  y0iv.resize((tt-3)*nn,1);
  
  if(nx ==1){
    sy1 = deltxs;
    sy1.resize(tt-1,nn);

    Eigen::MatrixXd sy12 = sy1.middleRows(1,tt-3).eval();

    Eigen::MatrixXd sy13 = sy1.topRows(tt-3).eval();

    y1iv << sy12;
    y2iv << sy13;
  }else{
    sy1 = deltxs.col(0);
    sx1 = deltxs.rightCols(nx-1);
    sy1.resize(tt-1,nn);
    sx1.resize(tt-1,(nx-1)*nn);
    
    Eigen::MatrixXd sy12 = sy1.middleRows(1,tt-3).eval();
    Eigen::MatrixXd sx12 = sx1.bottomRows(tt-3).eval();
    
    Eigen::MatrixXd sy13 = sy1.topRows(tt-3).eval();
    
    y1iv << sy12,sx12;
    y2iv << sy13,sx12;

  }
  
  
  
  y1iv.resize((tt-3)*nn,(nx));
  y2iv.resize((tt-3)*nn,(nx));
  
  xx1 = Eigen::MatrixXd::Zero((tt-1)*nn,(nx));
  xx1 = deltxs;
  xxc = Eigen::MatrixXd::Zero((tt-1)*nn,(nx+nx1));
  xxc << deltxs,ininxc;
  
  
  Eigen::MatrixXd betas = (y2iv.adjoint()*y1iv).inverse()*(y2iv.adjoint()*y0iv);
  
  Eigen::VectorXd betas0 = betas.col(0);
  
  Eigen::VectorXd pars0(nx+nx1),pars1(nx+nx1+2);
  pars0 << betas0,delts;
  Eigen::MatrixXd betas1(nx+nx1,1);
  betas1.col(0) = pars0;
  
  double sigmau0,w0,sigmau,wg;
  w0 = 2;
  
  omega1 = omega;
  omega1(0,0) = w0;
  Eigen::MatrixXd omega2 = omega1.inverse();
  
  dy0.resize((tt-1)*nn,1);
  initres = (dy0 - xxc*betas1);
  
  sigmau = 0;
  wg = 0;
  
  for(t=0;t<nn;t++){
    xnn = initres.middleRows(t*(tt-1),tt-1);
    uv = xnn.adjoint()*omega2*xnn;
    sigmau += uv(0,0);
    wv = xnn.adjoint()*faz*xnn;
    wg += wv(0,0);
  }
  
  sigmau = sigmau/(nn*(tt-1));
  double tn;
  tn = tt;
  
  wg = (tn-2)/(tn-1) + wg/(sigmau*nn*(pow(tt-1,2)));
  
  if(sigmau<0){
    sigmau = -sigmau;
  }
  
  if(wg<= (tt-2)/(tt-1)){
    wg = 1;
  }
  
  
  pars1 << betas0,delts,sigmau,wg;
  
  return List::create(_["pars1"] = pars1,_["xxc"] = xxc);
}


// [[Rcpp::export]]
double likelihood_c_1(Eigen::VectorXd &pars1,Eigen::MatrixXd &delty0,
                      Eigen::MatrixXd &evs,Eigen::MatrixXd &omega, int &cd, int &tt, int &nn){
  double likely_function_value,ww,tn,p3,p2,nb;
  Eigen::MatrixXd omega0(tt-1,tt-1),osolve(tt-1,tt-1),xn(tt-1,1),yn(tt-1,1),fits(tt-1,1),
  betas(cd-2,1),pp(1,1);
  int t;
  
  ww = pars1(cd-1);
  betas.col(0) = pars1.head(cd-2);
  tn = tt;
  nb = nn;
  omega0 = omega;
  if(ww <= (1 - 1/(tn - 1))){
    likely_function_value = numeric_limits<double>::infinity();
  }else{
    omega0(0,0) = ww;
    omega0 = omega0*pow(pars1(cd-2),2);
    pp(0,0) = 0;
    osolve = omega0.inverse();
    p3 = 0;
    
    for(t=0;t<nn;t++){
      xn = evs.middleRows(t*(tt-1),tt-1);
      yn = delty0.middleRows(t*(tt-1),tt-1);
      fits = (yn - xn*betas);
      pp = fits.adjoint()*osolve*fits;
      p3 += pp(0,0);
    }
    
    p2 = (1 + (tn-1)*(ww-1))*pow(pars1(cd-2),2*(tt-1));
    p2 = nb*log(p2);
    likely_function_value = 0.5*(p2+p3);
  }
  
  return likely_function_value;
  
}


// [[Rcpp::export]]
double likelihood_c_2(Eigen::VectorXd &pars1,Eigen::MatrixXd &delty0,
                      Eigen::MatrixXd &evs,Eigen::MatrixXd &omega, int &cd, int &tt, int &nn){
  double likely_function_value,ww,tn,p3,p2,nb,sg,p1;
  Eigen::MatrixXd omega0(tt-1,tt-1),osolve(tt-1,tt-1),xn(tt-1,1),yn(tt-1,1),fits(tt-1,1),
  betas(cd-2,1),pp(1,1);
  int t;
  
  sg = pars1(cd-2);
  ww = pars1(cd-1);
  betas.col(0) = pars1.head(cd-2);
  tn = tt;
  nb = nn;
  p1 = tn*nb*log(6.4);
  omega0 = omega;
  if(ww <= (1 - 1/(tn - 1)) || sg<=0){
    likely_function_value = numeric_limits<double>::infinity();
  }else{
    omega0(0,0) = ww;
    omega0 = omega0*sg;
    pp(0,0) = 0;
    osolve = omega0.inverse();
    p3 = 0;
    
    for(t=0;t<nn;t++){
      xn = evs.middleRows(t*(tt-1),tt-1);
      yn = delty0.middleRows(t*(tt-1),tt-1);
      fits = (yn - xn*betas);
      pp = fits.adjoint()*osolve*fits;
      p3 += pp(0,0);
    }
    
    p2 = (1 + (tn-1)*(ww-1))*pow(sg,(tt-1));
    p2 = nb*log(p2);
    likely_function_value = 0.5*(p1+p2+p3);
    if(likely_function_value<0){
      likely_function_value = numeric_limits<double>::infinity();
    }
  }
  
  return likely_function_value;
  
}


// [[Rcpp::export]]
List edt_cdt_1(Eigen::VectorXd &rt,Eigen::VectorXd &q, Eigen::MatrixXd &yitx,
             Eigen::MatrixXd &xx, int &tt, int &nn) {
  int nx,t;
  nx = xx.cols();
  Eigen::MatrixXd delty1p1(tt-2,nn),delty1p(tt-1,nn), yte(tt-1,nn),zsx(1,nx)
    ,deltxp(tt-1,nx),yte1(tt-2,nn),regime2(tt*nn,1),regime2x(tt*nn,1),zs(1,nn),
    xxte(tt,nx),xxte1(tt-1,nx);
  
  delty1p1 = Eigen::MatrixXd::Zero(tt-2,nn);
  deltxp = Eigen::MatrixXd::Zero(tt-2,nx);
  regime2 = Eigen::MatrixXd::Zero(tt*nn,1);
  zs = Eigen::MatrixXd::Zero(1,nn);
  zsx = Eigen::MatrixXd::Zero(1,nx);
  
  regime2.col(0) = rt;
  
  regime2x = regime2;
  regime2.resize(tt,nn);
  regime2x.resize(tt,nx);
  regime2 = regime2.bottomRows(tt-1).eval();
  
  yitx = yitx.topRows(tt-1).eval();
  
  yte = (yitx.array()*regime2.array()).eval();
  yte1 = yte.bottomRows(tt-2).eval();
  yte = yte.topRows(tt-2).eval();
  delty1p1 = yte1 - yte;
  delty1p << zs,
             delty1p1;
  delty1p.resize((tt-1)*nn,1);
  
  xxte = xx.array()*regime2x.array();
  
  xxte1 = xxte.bottomRows(tt-1).eval();
  xxte = xxte.topRows(tt-1).eval();
  
  deltxp = xxte1 - xxte;
  deltxp.row(0) = zsx.row(0);
  deltxp.resize((tt-1)*nn,nx/nn);
  return List::create(_["delty1p"] = delty1p,_["deltxp"] = deltxp);
}




// [[Rcpp::export]]
double MDEV(Eigen::VectorXd &pars1,Eigen::MatrixXd &delty0,
                      Eigen::MatrixXd &evs,Eigen::MatrixXd &omega, int &cd, int &tt, int &nn){
  double likely_function_value,ww,tn,p3,nb;
  Eigen::MatrixXd omega0(tt-1,tt-1),osolve(tt-1,tt-1),xn(tt-1,1),yn(tt-1,1),fits(tt-1,1),
  betas(cd-2,1),pp(1,1);
  int t;
  
  ww = pars1(cd-1);
  betas.col(0) = pars1.head(cd-2);
  tn = tt;
  nb = nn;
  omega0 = omega;
  if(ww < 0){
    ww = -ww;
  }
  if(ww <= (1 - 1/(tn - 1))){
    ww = ww+1.1;
  }
  omega0(0,0) = ww;
  omega0 = omega0*pow(pars1(cd-2),2);
  pp(0,0) = 0;
  osolve = omega0.inverse();
  p3 = 0;
  
  for(t=0;t<nn;t++){
    xn = evs.middleRows(t*(tt-1),tt-1);
    yn = delty0.middleRows(t*(tt-1),tt-1);
    fits = (yn - xn*betas);
    pp = fits.adjoint()*osolve*fits;
    p3 += pp(0,0);
  }
  
  likely_function_value = p3;
  
  return likely_function_value;
  
}
