MAP2 <- function (bayesianOutput, ...) 
{
  samples = BayesianTools::getSample(bayesianOutput, parametersOnly = F, 
                      ...)
  if ("mcmcSamplerList" %in% class(bayesianOutput)) 
    nPars <- bayesianOutput[[1]]$setup$numPars
  else nPars = bayesianOutput$setup$numPars
  best = which(samples[, nPars + 1] == max(samples[, nPars + 1]))
  cdb = length(best)
  if(cdb == 1){
    parametersMAP = samples[best, 1:nPars]
    valuesMAP = samples[best,(nPars + 1):(nPars + 3)]
  }else{
    samples2 = colMeans(samples[best,])
    parametersMAP = samples2[1:nPars]
    valuesMAP = samples2[(nPars + 1):(nPars + 3)]
  }
  
  return(list(parametersMAP = parametersMAP, valuesMAP = valuesMAP))
}