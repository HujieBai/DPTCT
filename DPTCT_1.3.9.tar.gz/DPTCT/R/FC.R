#'The threshold constancy test.
#'
#'@param y Vector input; Explained variable variable.
#'@param x Matrix input; explanatory variables; The number of cols is the kinds
#'of variables.
#'@param q Vector input; threhsodl variable.
#'@param cvs Matrix input; When it is not a threshold model, here should be
#'NUll. And cvs are the control variables.
#'@param time_trend Matrix input; Time shifts or other cvs (i0=1)).
#'@param st Matrix input; covariates uesd in thresholds.
#'@param tt int/double input; The length of Time-period.
#'@param nn int/double input; The number of individuals.
#'@param bt int/double input; The number of bootstrap.
#'@param ms int input; the length of MCMC chain after burning.
#'@param burnin int input; the length of burning period.
#'@param parallel T/F; Default is F; When parallel is T, the test would run in 
#'parallel (i.e. using more cpus to reduce the computional time.)
#'@param sdu int/double input; the initial value of the standard error of residuals; Only be used when
#'sd(y) is too small.
#'@author Hujie Bai
#'@references Lixiong Yang and Hujie Bai (2023), Maximum likelihood estimation 
#'of dynamic panel threshold model with a covariate- dependent threshold.
#'@examples
#'\dontrun{
#'d1 =  dgpcDT(5,50,r0=0.2,r1=0)
#'LRtest = LRtest = FC(y=d1$y,x=d1$x,q=d1$q,cvs = as.matrix(d1$z)
#',st=d1$st,tt = d1$tt,nn = d1$nn,burnin = 1000)
#'LRtest$ps
#'}
#'@export
FC = function(y,x=NULL,q,cvs=NULL,time_trend =NULL,st,sdu=NULL,tt,nn,bt=100,ms = 1000,burnin=500,parallel=FALSE){
  
  m0 = DPTCs(y=y,x=x,q=q,cvs = cvs,time_trend = time_trend,sdu = sdu
             ,tt = tt,nn = nn,ms =ms,burnin = burnin)
  m1 = DPTCTs(y=y,x=x,q=q,cvs = cvs,time_trend = time_trend,sdu = sdu
              ,st=st,tt = tt,nn = nn,ms =ms,burnin = burnin)
  
  du = matrix(m0$model$duit,tt-1)
  dy = matrix(m0$model$dy0,tt-1)
  dfit = dy - du
  m1s <- m1$model$ssemin
  if(m0$model$ssemin < m1$model$ssemin){
    m1s <- m0$model$ssemin
  }
  LRs = (m0$model$ssemin - m1s)/(m1s/((tt-2)*nn))
  
  i=0
  btprocedure = function(j){
    cy = sample(1:nn,nn,replace = TRUE)
    dub = du[,cy]
    dyb = matrix(dfit + dub,ncol = 1)
    
    m0b = DPTCs3(y=y, delty0 = dyb,x=x,q=q,cvs = cvs,time_trend = time_trend,sdu = sdu
                ,tt = tt,nn = nn,ms =ms,burnin = burnin)
    m1b = DPTCTs3(y=y, delty0 = dyb,x=x,q=q,cvs = cvs,time_trend = time_trend,sdu = sdu
                 ,st=st,tt = tt,nn = nn,ms =ms,burnin = burnin)
    
    m1sb <- m1b$model$ssemin
    if(m0b$model$ssemin < m1b$model$ssemin){
      m1sb <- m0b$model$ssemin
    }
    LRsb = (m0b$model$ssemin - m1sb)/(m1sb/((tt-2)*nn))
    pbt = "No"
    if(LRsb>=LRs){
      pbt = "exceeded"
    }
    cat('\n')
    cat(j,"/",bt,pbt)
    cat('\n')
    return(LRsb)
  }
  
  if(!isTRUE(parallel)){
    FS = as.numeric(na.omit(purrr::map_dbl(1:bt,btprocedure)))
  }else{
    xc= parallel::detectCores()
    xc = xc -1
    Btimes <- bt
    pb <- utils::txtProgressBar(min=1, max=Btimes, style=3)
    progress <- function(n) utils::setTxtProgressBar(pb, n)
    opts <- list(progress=progress)
    cl <- snow::makeSOCKcluster(xc)
    doSNOW::registerDoSNOW(cl)
    
    FS <- foreach::foreach(i=1:Btimes, .packages = c('purrr','SparseM','Rcpp',"BayesianTools"), .options.snow=opts,
                           .combine=c,.errorhandling = "remove") %dopar%{
                             bt_p = btprocedure(i)
                             return(bt_p)
                           }
    
    close(pb)
    snow::stopCluster(cl)
  }
  
  ps = mean(FS>=LRs)
  crit = stats::quantile(FS,probs=0.95)
  
  js = list(ps = ps,crit = crit,LR=LRs,LRs = FS)
  cat("   P-value = ",ps)
  
  return(js)
  
  
}