#'Dynamic panel fixed effects model.
#'
#'@param y Vector input; Explained variable variable.
#'@param x Matrix input; explanatory variables; The number of cols is the kinds
#'of variables.
#'@param x1 Matrix input; Here is equal to x.
#'@param cvs Matrix input; When it is not a threshold model, here should be
#'NUll. And cvs are the control variables.
#'@param tt int/double input; The length of Time-period.
#'@param nn int/double input; The number of individuals.
#'@param sdu int/double input; the initial value of the standard error of residuals; Only be used when
#'sd(y) is too small.
#'@description
#'It allows the lack of x.
#'
#'@return This function will return a list; ssemin is the loss function value
#'of the model;par is a vector of model coefficients; duit is the first
#'difference of error term uit; dy0 is the first difference of y; xx is the
#'matrix of all explanatory variables; Covariance_matrix is the covariance
#'matrix of all model coefficients (without threshold parameters); Ses is the
#'standard error; Zvalues is the Z or T value; S0 is the value of the minimum
#'distance estimator.
#'@author Hujie Bai.
#'@references Hsiao, C., Pesaran, M. H., \& Tahmiscioglu, A. K. (2002). Maximum
#' likelihood estimation of fixed effects dynamic panel data models covering
#' short time periods.  Journal of econometrics, 109(1), 107-150.
#'@examples
#'# d1 = dgpcDT(5,50,b2=0,c2=0)
#'#'test1 = DPMs02(y=d1$y,x=d1$x,x1=d1$x,tt=d1$tt,nn=d1$nn)
#'#'test1$par
#'#'test1$Zvalues
#'@importFrom stats na.omit nlm quantile rnorm
#'@importFrom BayesianTools createBayesianSetup createUniformPrior getSample runMCMC
#'@importFrom foreach %dopar% foreach
#'@useDynLib DPTCT
#'@import RcppEigen
#'@importFrom Rcpp evalCpp
#'@export
DPMs02 = function(y,x=NULL,x1=NULL,cvs=NULL,sdu = NULL,tt,nn){
  n=nn
  yitx = matrix(y,nrow = tt,ncol = n)
  delty0 = matrix(yitx[-1,] - yitx[-(tt),],ncol = 1)
  
  XX = matrix(rbind(rep(0,nn),matrix(y,tt,nn)[-tt,]),ncol = 1)
  insertvalue = matrix(0,nrow = (tt-1),ncol = nn)
  insertvalue[1,] = rep(1,nn)
  insertvalue = matrix(insertvalue,ncol = 1)
  
  ininxc<- insertvalue
  
  z0=0
  x0=0
  if(!is.null(x)){
    XX = cbind(XX,x)
    x0 = ncol(x)
  }
  if(!is.null(cvs)){
    XX = cbind(XX,cvs)
    z0 = ncol(cvs)
  }
  
  
  
  if(!is.null(x1)){
    ininxc<- insertvalue
    xx = matrix(x1,nrow = (tt))
    nk = ncol(xx)
    deltxi1 = xx[-1,] - xx[-tt,]
    deltxi1[2:(tt-1),] = 0
    deltxi1 = matrix(deltxi1,ncol = ncol(x1))
    ininxc<- cbind(ininxc,deltxi1)
  }

  
  xx = matrix(XX,nrow = (tt))
  nk = ncol(xx)
  deltxs = xx[-1,] - xx[-(tt),]
  deltxs[1,] = 0
  deltxs = matrix(deltxs,ncol = ncol(XX))
  
  
  x1int = matrix(matrix(ininxc,nrow = tt-1)[1,],nrow = nn)

  yint = matrix(matrix(delty0,nrow = (tt-1))[1,],ncol = 1)
  delts <- qr.solve(x1int,as.vector(yint))
  
  omega = diag(2,nrow = (tt-1),ncol = (tt-1))
  diag(omega[-1,-(tt-1)]) = -1
  diag(omega[-(tt-1),-1]) = -1
  
  faz = matrix(sort(1:(tt-1),decreasing = TRUE),nrow = (tt-1),ncol = (tt-1),
               byrow = TRUE)*matrix(sort(1:(tt-1),decreasing = TRUE),
                                    nrow = (tt-1),ncol = (tt-1))
  
  tp = tr_c_4x(delty0, deltxs,ininxc, omega, faz, delts, tt, nn)
  
  pars1 = tp$pars1
  cd = length(pars1)
  if(!is.null(sdu)){
    pars1[cd-1] = sdu
  }
  if(is.na((pars1[cd-1]>8000))){
    pars = 1e7
    ssemin = 1e7
    
    duit = 1e7
    cms = 1e7
    ses = 1e7
    zvalues = 1e7
    S0 = 1e7
  }else{
    if(pars1[cd-1]>1000){
      pars1[cd-1] = 1
    }
    result_in = suppressWarnings(try(stats::nlm(likelihood_c_2,pars1,delty0=delty0,evs=tp$xxc,omega=omega,cd=cd,tt=tt,nn=nn,iterlim = 500),silent = TRUE))
    
    if('try-error' %in% class(result_in)){
      pars = 1e7
      ssemin = 1e7
      
      duit = 1e7
      cms = 1e7
      ses = 1e7
      zvalues = 1e7
      S0 = 1e7
    }else{
      pars = result_in$estimate
      ssemin = result_in$minimum
      
      duit = (delty0 - tp$xxc%*%(pars[c(-(cd-1),-cd)]))
      
     
      evs=tp$xxc[,1:(cd-2)]
      if(z0==0&x0==0){
        evs = matrix(evs,ncol = 1)
      }
      bets = pars[1:(cd-2)]
      
      cms = matrix(0,nrow = ncol(evs),ncol = ncol(evs))
      
      xomega = omega
      xomega[1,1] = pars[cd]
      xomega = xomega*pars[cd-1]
      xomega = solve(xomega)
      
      for (i in 1:nn) {
        cms = cms + t(evs[((tt-1)*(i-1)+1):((tt-1)*i),])%*%xomega%*%(evs[((tt-1)*(i-1)+1):((tt-1)*i),])
      }
      cms = try(MASS::ginv(cms),silent = TRUE)
      if('try-error' %in% class(cms)){
        ses = "singular"
        zvalues = "singular"
        cms = "singular"
      }else{
        ses = sqrt(abs(diag(cms)))
        zvalues = bets/ses
      }
      S0 = 2*ssemin - nn*log((1+(tt-1)*(pars[length(pars)]-1))*((pars[length(pars)-1])^(tt-1)))
    }
  }
  
  
  
 
  
  
  jieguo = list(ssemin = ssemin,par = pars,duit = duit,dy0=delty0,xx=tp$xxc,covariance_matrix = cms,Ses= ses,Zvalues = zvalues,S0=S0)
  
  
  return(jieguo)
}


DPMs002 = function(y,x=NULL,x1=NULL,cvs=NULL,sdu = NULL,tt,nn){
 
  n=nn
  yitx = matrix(y,nrow = tt,ncol = n)
  delty0 = matrix(yitx[-1,] - yitx[-(tt),],ncol = 1) 
  

  insertvalue = matrix(0,nrow = (tt-1),ncol = nn)
  insertvalue[1,] = rep(1,nn)
  insertvalue = matrix(insertvalue,ncol = 1)
  
  ininxc<- insertvalue
  
  z0=0
  x0=0

  XX = x
  x0 = ncol(x)

  if(!is.null(cvs)){
    XX = cbind(XX,cvs)
    z0 = ncol(cvs)
  }

  
  
  if(!is.null(x1)){
    xx = matrix(x1,nrow = (tt))
    nk = ncol(xx)
    deltxi1 = xx[-1,] - xx[-tt,]
    deltxi1[2:(tt-1),] = 0
    deltxi1 = matrix(deltxi1,ncol = ncol(x1))
    ininxc<- cbind(ininxc,deltxi1)
  }
  
  
  xx = matrix(XX,nrow = (tt))
  nk = ncol(xx)
  deltxs = xx[-1,] - xx[-(tt),]
  deltxs[1,] = 0
  deltxs = matrix(deltxs,ncol = ncol(XX))
  
  
  x1int = matrix(matrix(ininxc,nrow = tt-1)[1,],nrow = nn)
  
  yint = matrix(matrix(delty0,nrow = (tt-1))[1,],ncol = 1)
  delts <- qr.solve(x1int,as.vector(yint))
  

  
  
  omega = diag(2,nrow = (tt-1),ncol = (tt-1))
  diag(omega[-1,-(tt-1)]) = -1
  diag(omega[-(tt-1),-1]) = -1
  
  faz = matrix(sort(1:(tt-1),decreasing = TRUE),nrow = (tt-1),ncol = (tt-1),
               byrow = TRUE)*matrix(sort(1:(tt-1),decreasing = TRUE),
                                    nrow = (tt-1),ncol = (tt-1))
  
  tp = tr_c_4x(delty0, deltxs,ininxc, omega, faz, delts, tt, nn)
  
  pars1 = tp$pars1
  cd = length(pars1)
  if(!is.null(sdu)){
    pars1[cd-1] = sdu
  }
  if(is.na((pars1[cd-1]>8000))){
    pars = 1e7
    ssemin = 1e7
    
    duit = 1e7
    cms = 1e7
    ses = 1e7
    zvalues = 1e7
    S0 = 1e7
  }else{
    if(pars1[cd-1]>1000){
      pars1[cd-1] = 1
    }
    result_in = suppressWarnings(try(stats::nlm(likelihood_c_2,pars1,delty0=delty0,evs=tp$xxc,omega=omega,cd=cd,tt=tt,nn=nn,iterlim = 500),silent = TRUE))
    
    if('try-error' %in% class(result_in)){
      pars = 1e7
      ssemin = 1e7
      
      duit = 1e7
      cms = 1e7
      ses = 1e7
      zvalues = 1e7
      S0 = 1e7
    }else{
      pars = result_in$estimate
      ssemin = result_in$minimum
      
      duit = (delty0 - tp$xxc%*%(pars[c(-(cd-1),-cd)]))
      
      
      evs=tp$xxc[,1:(cd-2)]
      if(z0==0&x0==0){
        evs = matrix(evs,ncol = 1)
      }
      bets = pars[1:(cd-2)]
      
      cms = matrix(0,nrow = ncol(evs),ncol = ncol(evs))
      
      xomega = omega
      xomega[1,1] = pars[cd]
      xomega = xomega*pars[cd-1]
      xomega = solve(xomega)
      
      for (i in 1:nn) {
        cms = cms + t(evs[((tt-1)*(i-1)+1):((tt-1)*i),])%*%xomega%*%(evs[((tt-1)*(i-1)+1):((tt-1)*i),])
      }
      cms = try(MASS::ginv(cms),silent = TRUE)
      if('try-error' %in% class(cms)){
        ses = "singular"
        zvalues = "singular"
        cms = "singular"
      }else{
        ses = sqrt(abs(diag(cms)))
        zvalues = bets/ses
      }
      S0 = 2*ssemin - nn*log((1+(tt-1)*(pars[length(pars)]-1))*((pars[length(pars)-1])^(tt-1)))
    }
  }
  
  
  
  
  
  
  jieguo = list(ssemin = ssemin,par = pars,duit = duit,dy0=delty0,xx=tp$xxc,covariance_matrix = cms,Ses= ses,Zvalues = zvalues,S0=S0)
  
  
  return(jieguo)
}

DPMs0 = function(y,x=NULL,x1=NULL,cvs=NULL,sdu = NULL,tt,nn){
 
  n=nn
  yitx = matrix(y,nrow = tt,ncol = n) 
  delty0 = matrix(yitx[-1,] - yitx[-(tt),],ncol = 1) 
  
  XX = matrix(rbind(rep(0,nn),matrix(y,tt,nn)[-tt,]),ncol = 1)
  insertvalue = matrix(0,nrow = (tt-1),ncol = nn)
  insertvalue[1,] = rep(1,nn)
  insertvalue = matrix(insertvalue,ncol = 1)
  
  ininxc<- insertvalue
  
  if(!is.null(x)){
    XX = cbind(XX,x)
  }
  if(!is.null(cvs)){
    XX = cbind(XX,cvs)
  }
  

  if(!is.null(x1)){
    ininxc<- insertvalue
    xx = matrix(x1,nrow = (tt))
    nk = ncol(xx)
    deltxi1 = xx[-1,] - xx[-tt,]
    deltxi1[2:(tt-1),] = 0
    deltxi1 = matrix(deltxi1,ncol = ncol(x1))
    ininxc<- cbind(ininxc,deltxi1)
  }
  
  
  xx = matrix(XX,nrow = (tt))
  nk = ncol(xx)
  deltxs = xx[-1,] - xx[-(tt),]
  deltxs[1,] = 0
  deltxs = matrix(deltxs,ncol = ncol(XX))
  
  
  x1int = matrix(matrix(ininxc,nrow = tt-1)[1,],nrow = nn)
  
  yint = matrix(matrix(delty0,nrow = (tt-1))[1,],ncol = 1)
  delts <- qr.solve(x1int,as.vector(yint))
  
  
  omega = diag(2,nrow = (tt-1),ncol = (tt-1))
  diag(omega[-1,-(tt-1)]) = -1
  diag(omega[-(tt-1),-1]) = -1
  
  faz = matrix(sort(1:(tt-1),decreasing = TRUE),nrow = (tt-1),ncol = (tt-1),
               byrow = TRUE)*matrix(sort(1:(tt-1),decreasing = TRUE),
                                    nrow = (tt-1),ncol = (tt-1))
  
  tp = tr_c_4x(delty0, deltxs,ininxc, omega, faz, delts, tt, nn)
  
  pars1 = tp$pars1
  cd = length(pars1)
  if(!is.null(sdu)){
    pars1[cd-1] = sdu
  }
  if(is.na((pars1[cd-1]>8000))){
    pars = Inf
    ssemin = Inf
    
    duit = Inf
  }else{
    if(pars1[cd-1]>8000){
      pars1[cd-1] = 1
    }
    result_in = suppressWarnings(try(stats::nlm(likelihood_c_2,pars1,delty0=delty0,evs=tp$xxc,omega=omega,cd=cd,tt=tt,nn=nn,iterlim = 500),silent = TRUE))
    
    if('try-error' %in% class(result_in)){
      pars = Inf
      ssemin = Inf
      
      duit = Inf
    }else{
      pars = result_in$estimate
      ssemin = result_in$minimum
      
      duit = (delty0 - tp$xxc%*%(pars[c(-(cd-1),-cd)]))
    }
  }
  
  
  
  
  
  jieguo = list(ssemin = ssemin,par = pars,duit = duit,dy0=delty0,xx=tp$xxc)
  
  
  return(jieguo)
}
DPMs00 = function(y,x=NULL,x1=NULL,cvs=NULL,sdu = NULL,tt,nn){
 
  n=nn
  yitx = matrix(y,nrow = tt,ncol = n) 
  delty0 = matrix(yitx[-1,] - yitx[-(tt),],ncol = 1) 
  
 
  insertvalue = matrix(0,nrow = (tt-1),ncol = nn)
  insertvalue[1,] = rep(1,nn)
  insertvalue = matrix(insertvalue,ncol = 1)
  
  ininxc<- insertvalue
  

    XX = x

  if(!is.null(cvs)){
    XX = cbind(XX,cvs)
  }
  
  
  
  if(!is.null(x1)){
    xx = matrix(x1,nrow = (tt))
    nk = ncol(xx)
    deltxi1 = xx[-1,] - xx[-tt,]
    deltxi1[2:(tt-1),] = 0
    deltxi1 = matrix(deltxi1,ncol = ncol(x1))
    ininxc<- cbind(ininxc,deltxi1)
  }
  
  
  xx = matrix(XX,nrow = (tt))
  nk = ncol(xx)
  deltxs = xx[-1,] - xx[-(tt),]
  deltxs[1,] = 0
  deltxs = matrix(deltxs,ncol = ncol(XX))
  
  
  x1int = matrix(matrix(ininxc,nrow = tt-1)[1,],nrow = nn)
  
  yint = matrix(matrix(delty0,nrow = (tt-1))[1,],ncol = 1)
  delts <- qr.solve(x1int,as.vector(yint))
  
  omega = diag(2,nrow = (tt-1),ncol = (tt-1))
  diag(omega[-1,-(tt-1)]) = -1
  diag(omega[-(tt-1),-1]) = -1
  
  faz = matrix(sort(1:(tt-1),decreasing = TRUE),nrow = (tt-1),ncol = (tt-1),
               byrow = TRUE)*matrix(sort(1:(tt-1),decreasing = TRUE),
                                    nrow = (tt-1),ncol = (tt-1))
  
  tp = tr_c_4x(delty0, deltxs,ininxc, omega, faz, delts, tt, nn)
  
  pars1 = tp$pars1
  cd = length(pars1)
  if(!is.null(sdu)){
    pars1[cd-1] = sdu
  }
  if(is.na((pars1[cd-1]>8000))){
    pars = Inf
    ssemin = Inf
    
    duit = Inf
  }else{
    if((pars1[cd-1]>8000)){
      pars1[cd-1] = 1
    }
    result_in = suppressWarnings(try(stats::nlm(likelihood_c_2,pars1,delty0=delty0,evs=tp$xxc,omega=omega,cd=cd,tt=tt,nn=nn,iterlim = 500),silent = TRUE))
    
    if('try-error' %in% class(result_in)){
      pars = Inf
      ssemin = Inf
      
      duit = Inf
    }else{
      pars = result_in$estimate
      ssemin = result_in$minimum
      
      duit = (delty0 - tp$xxc%*%(pars[c(-(cd-1),-cd)]))
    }
  }
  
  
  
  
  jieguo = list(ssemin = ssemin,par = pars,duit = duit,dy0=delty0,xx=tp$xxc)
  
  
  return(jieguo)
}


DPMs03 = function(y,delty0 = NULL,x=NULL,x1=NULL,cvs=NULL,sdu = NULL,tt,nn){
 
  n=nn
  yitx = matrix(y,nrow = tt,ncol = n)
  delty0 = delty0 
  
  XX = matrix(rbind(rep(0,nn),matrix(y,tt,nn)[-tt,]),ncol = 1)
  insertvalue = matrix(0,nrow = (tt-1),ncol = nn)
  insertvalue[1,] = rep(1,nn)
  insertvalue = matrix(insertvalue,ncol = 1)
  
  ininxc<- insertvalue
  
  z0=0
  x0=0
  if(!is.null(x)){
    XX = cbind(XX,x)
    x0 = ncol(x)
  }
  if(!is.null(cvs)){
    XX = cbind(XX,cvs)
    z0 = ncol(cvs)
  }
  
 
  
  if(!is.null(x1)){
    ininxc<- insertvalue
    xx = matrix(x1,nrow = (tt))
    nk = ncol(xx)
    deltxi1 = xx[-1,] - xx[-tt,]
    deltxi1[2:(tt-1),] = 0
    deltxi1 = matrix(deltxi1,ncol = ncol(x1))
    ininxc<- cbind(ininxc,deltxi1)
  }
  
  
  xx = matrix(XX,nrow = (tt))
  nk = ncol(xx)
  deltxs = xx[-1,] - xx[-(tt),]
  deltxs[1,] = 0
  deltxs = matrix(deltxs,ncol = ncol(XX))
  
  
  x1int = matrix(matrix(ininxc,nrow = tt-1)[1,],nrow = nn)
  
  yint = matrix(matrix(delty0,nrow = (tt-1))[1,],ncol = 1)
  delts <- qr.solve(x1int,as.vector(yint))
  
  

  
  
  
  omega = diag(2,nrow = (tt-1),ncol = (tt-1))
  diag(omega[-1,-(tt-1)]) = -1
  diag(omega[-(tt-1),-1]) = -1
  
  faz = matrix(sort(1:(tt-1),decreasing = TRUE),nrow = (tt-1),ncol = (tt-1),
               byrow = TRUE)*matrix(sort(1:(tt-1),decreasing = TRUE),
                                    nrow = (tt-1),ncol = (tt-1))
  
  tp = tr_c_4x(delty0, deltxs,ininxc, omega, faz, delts, tt, nn)
  
  pars1 = tp$pars1
  cd = length(pars1)
  if(!is.null(sdu)){
    pars1[cd-1] = sdu
  }
  if(is.na((pars1[cd-1]>8000))){
    pars = 1e7
    ssemin = 1e7
    
    duit = 1e7
    cms = 1e7
    ses = 1e7
    zvalues = 1e7
    S0 = 1e7
  }else{
    if(pars1[cd-1]>1000){
      pars1[cd-1] = 1
    }
    result_in = suppressWarnings(try(stats::nlm(likelihood_c_2,pars1,delty0=delty0,evs=tp$xxc,omega=omega,cd=cd,tt=tt,nn=nn,iterlim = 500),silent = TRUE))
    
    if('try-error' %in% class(result_in)){
      pars = 1e7
      ssemin = 1e7
      
      duit = 1e7
      cms = 1e7
      ses = 1e7
      zvalues = 1e7
      S0 = 1e7
    }else{
      pars = result_in$estimate
      ssemin = result_in$minimum
      
      duit = (delty0 - tp$xxc%*%(pars[c(-(cd-1),-cd)]))
      
      
      evs=tp$xxc[,1:(cd-2)]
      if(z0==0&x0==0){
        evs = matrix(evs,ncol = 1)
      }
      bets = pars[1:(cd-2)]
    
      cms = matrix(0,nrow = ncol(evs),ncol = ncol(evs))
      
      xomega = omega
      xomega[1,1] = pars[cd]
      xomega = xomega*pars[cd-1]
      xomega = solve(xomega)
      
      for (i in 1:nn) {
        cms = cms + t(evs[((tt-1)*(i-1)+1):((tt-1)*i),])%*%xomega%*%(evs[((tt-1)*(i-1)+1):((tt-1)*i),])
      }
      cms = try(MASS::ginv(cms),silent = TRUE)
      if('try-error' %in% class(cms)){
        ses = "singular"
        zvalues = "singular"
        cms = "singular"
      }else{
        ses = sqrt(abs(diag(cms)))
        zvalues = bets/ses
      }
      S0 = 2*ssemin - nn*log((1+(tt-1)*(pars[length(pars)]-1))*((pars[length(pars)-1])^(tt-1)))
    }
  }
  
  
  

  
  
  jieguo = list(ssemin = ssemin,par = pars,duit = duit,dy0=delty0,xx=tp$xxc,covariance_matrix = cms,Ses= ses,Zvalues = zvalues,S0=S0)
  
  
  return(jieguo)
}
