#'Dynamic panel fixed effects panel model with, at most, 4 constant thresholds.
#'More see dgpcDT.
#'@param y Vector input; Explained variable variable.
#'@param x Matrix input; explanatory variables; The number of cols is the kinds
#'of variables.
#'@param q Vector input; threhsodl variable.
#'@param cvs Matrix input; When it is not a threshold model, here should be
#'NUll. And cvs are the control variables.
#'@param time_trend Matrix input; Time shifts or other cvs (i0=1)).
#'@param tt int/double input; The length of Time-period.
#'@param nn int/double input; The number of individuals.
#'@param ms int input; the length of MCMC chain after burning.
#'@param burnin int input; the length of burning period.
#'@param types char; the type of MCMC, see more in runMCMC of BayesianTools package.
#'@param ADs char; If the type == "Metropolis" and ADs == "True", the MCMC will be AMH.
#'@param Th int input; the number of thresholds.
#'@param inittype1 weakly or strictly exogenous regressors.
#'@param sdu int/double input; the initial value of the standard error of residuals; Only be used when
#'sd(y) is too small.
#'@author Hujie Bai.
#'@references Ramírez-Rondán, N. R. (2020). Maximum likelihood estimation of 
#'dynamic panel threshold models. Econometric Reviews, 39(3), 260-276.
#'@examples 
#'d1 = dgpcDT(5,50,r0=0.2,r1=0)
#'mc = DPTCs(y=d1$y,x=d1$x,q=d1$q,cvs = d1$cvs,time_trend = NULL,tt = d1$tt,
#'nn = d1$nn,ms=1000,burnin = 500,Th=1)
#'mc$Th1
#'mc$IC
#'mc$coefs
#'mc$model$Zvalues
#'@export
DPTCs = function(y,x=NULL,q,cvs=NULL,time_trend =NULL,tt,nn,sdu = NULL,ms = 1000,burnin=500,types = "DREAMzs",ADs = FALSE,Th = 1,inittype1 = FALSE){
  n=nn
  r0 <- stats::quantile(q, probs = 0.15)
  r1 <- stats::quantile(q, probs = 0.85)
  
  x1 = cbind(x,cvs)
  
  y1 = matrix(rbind(rep(0,nn),matrix(y,tt,nn)[-tt,]),ncol = 1)
  xx = x
  yy_1 = matrix(y1,nrow = nrow(y1),ncol = (Th))
  
  cvs0 = cbind(cvs,time_trend)
  
  nx = 0
  if(!is.null(x)){
    nx=ncol(x)
    xx = matrix(x,nrow = nrow(x),ncol = (ncol(x)*(Th+1)))
  }
  
  
  mm0 =DPMs02(y=y,x=x,x1=cbind(x,cvs),cvs = cvs0,sdu=sdu,tt = tt,nn = nn)
  sse0x = mm0$ssemin
  
  msx = function(ga){
    rts <- matrix(q,nrow = n*tt,ncol = (Th)) - matrix(ga,nrow  = n*tt,ncol = Th,byrow = TRUE)
    rts[which(rts>0,arr.ind = TRUE)] <- 1
    rts[which(rts<=0,arr.ind = TRUE)] <- 0
    rtss <- matrix(rts,n*tt,nx*Th)
    rts0 <- cbind(matrix(1,n*tt,nx),rtss)
    
    if(any(colSums(rts)<0.05*(tt*n))){
      sse0 = sse0x
    }else{
      xxx = cbind(yy_1*rts,xx*rts0)
      if(qr(xxx)$rank <ncol(xxx)){
        sse0 = sse0x
      }else{
        if(isTRUE(inittype1)){
          x1=cbind(xxx,cvs)
        }
        mx = DPMs0(y=y,x=xxx,x1=x1,cvs=cvs0,sdu=sdu,tt=tt,nn=nn)
        sse0 = mx$ssemin
      }
    }
    
    return(sse0)
  }
  
  
  pf1 = function(ga){
    s1 = msx(ga)
    return(-s1)
  }
  
  priors <- BayesianTools::createUniformPrior(lower = c(rep(r0,Th)), upper = c(rep(r1,Th)))
  bayesianSetup <- BayesianTools::createBayesianSetup(pf1, prior = priors)
  if(types == "Metropolis"){
    settings = list(iterations = (ms+burnin),burnin=burnin,adapt = ADs,adaptationNotBefore = (ms+burnin))
  }else{
    settings = list(iterations = (ms+burnin),burnin=burnin)
  }
  
  
  out <- BayesianTools::runMCMC(bayesianSetup = bayesianSetup, 
                                sampler = types, 
                                settings = settings)
  
  samples = BayesianTools::getSample(out,parametersOnly = F)
  mres = MAP2(out)
  gamma0 = mres[[1]]
  #gamma0 = colMeans(samples[which(samples[,(ncol(samples)-1)]==max(samples[,(ncol(samples)-1)])),1:(ncol(samples)-3)])
  ssemin = -mres[[2]][2]
  
  
  rts <- matrix(q,nrow = n*tt,ncol = Th) - matrix(gamma0,nrow  = n*tt,ncol = Th,byrow = TRUE)
  rts[which(rts>0,arr.ind = TRUE)] <- 1
  rts[which(rts<=0,arr.ind = TRUE)] <- 0
  rtss <- matrix(rts,n*tt,nx*Th)
  rts0 <- cbind(matrix(1,n*tt,nx),rtss)
  
  xxx = cbind(yy_1*rts,xx*rts0)
  
  
  if(isTRUE(inittype1)){
    x1=cbind(xxx,cvs)
  }
  
  
  if(qr(xxx)$rank <ncol(xxx)){
    mx = DPMs02(y=y,x=x,x1=cbind(x,cvs),cvs=cvs0,sdu=sdu,tt=tt,nn=nn)
    pars = mx$par
  }else{
    mx = DPMs02(y=y,x=xxx,x1=x1,cvs=cvs0,sdu=sdu,tt=tt,nn=nn)
    
    pars = mx$par
    if(length(pars)>1){
      pars = mx$par[1:(length(mx$par)-3-ncol(x1))]
      nx = ifelse(is.null(x),0,ncol(x))
      nz = ifelse(is.null(cvs0),0,ncol(cvs0))
      names(pars) <- c(rep("y1",Th+1),rep("x",(Th+1)*nx),rep("cvs",nz))
    }
  }
  
  
  IC = matrix(0,3,Th*2)
  
  colnames(IC) <- rep(c("Lower","Upper"),Th)
  rownames(IC) <- c("90%","95%","99%")
  
  for (i in 1:Th) {
    IC[1,(2*i-1):(2*i)] = c(stats::quantile(samples[,i],0.05),stats::quantile(samples[,i],0.95))
    IC[2,(2*i-1):(2*i)] = c(stats::quantile(samples[,i],0.025),stats::quantile(samples[,i],0.975))
    IC[3,(2*i-1):(2*i)] = c(stats::quantile(samples[,i],0.005),stats::quantile(samples[,i],0.995))
  }
  
  jieguo = list(gamma = gamma0,coefs = pars,model = mx,mcmc = samples,IC =IC)
  
  
  
  return(jieguo)
}

DPTCs3 = function(y, delty0 =NULL,x=NULL,q,cvs=NULL,time_trend =NULL,tt,nn,sdu = NULL,ms = 1000,burnin=500,types = "DREAMzs",ADs = FALSE,Th = 1,inittype1 = FALSE){
  n=nn
  r0 <- stats::quantile(q, probs = 0.15)
  r1 <- stats::quantile(q, probs = 0.85)
  
  x1 = cbind(x,cvs)
  
  y1 = matrix(rbind(rep(0,nn),matrix(y,tt,nn)[-tt,]),ncol = 1)
  xx = x
  yy_1 = matrix(y1,nrow = nrow(y1),ncol = (Th))
  
  cvs0 = cbind(cvs,time_trend)
  
  nx = 0
  if(!is.null(x)){
    nx=ncol(x)
    xx = matrix(x,nrow = nrow(x),ncol = (ncol(x)*(Th+1)))
  }
  
  
  
  mm0 =DPMs03(y=y, delty0 = delty0,x=x,x1=cbind(x,cvs),cvs = cvs0,sdu=sdu,tt = tt,nn = nn)
  sse0x = mm0$ssemin
  
  msx = function(ga){
    rts <- matrix(q,nrow = n*tt,ncol = (Th)) - matrix(ga,nrow  = n*tt,ncol = Th,byrow = TRUE)
    rts[which(rts>0,arr.ind = TRUE)] <- 1
    rts[which(rts<=0,arr.ind = TRUE)] <- 0
    rtss <- matrix(rts,n*tt,nx*Th)
    rts0 <- cbind(matrix(1,n*tt,nx),rtss)
    
    if(any(colSums(rts)<0.05*(tt*n))){
      sse0 = sse0x
    }else{
      xxx = cbind(yy_1*rts,xx*rts0)
      if(qr(xxx)$rank <ncol(xxx)){
        sse0 = sse0x
      }else{
        if(isTRUE(inittype1)){
          x1=cbind(xxx,cvs)
        }
        mx = DPMs03(y=y,delty0 =delty0,x=xxx,x1=x1,cvs=cvs0,sdu=sdu,tt=tt,nn=nn)
        sse0 = mx$ssemin
      }
    }
    
    return(sse0)
  }
  
  
  
  
  pf1 = function(ga){
    s1 = msx(ga)
    return(-s1)
  }
  
  priors <- BayesianTools::createUniformPrior(lower = c(rep(r0,Th)), upper = c(rep(r1,Th)))
  bayesianSetup <- BayesianTools::createBayesianSetup(pf1, prior = priors)
  if(types == "Metropolis"){
    settings = list(iterations = (ms+burnin),burnin=burnin,adapt = ADs,adaptationNotBefore = (ms+burnin))
  }else{
    settings = list(iterations = (ms+burnin),burnin=burnin)
  }
  
  
  out <- BayesianTools::runMCMC(bayesianSetup = bayesianSetup, 
                                sampler = types, 
                                settings = settings)
  
  samples = BayesianTools::getSample(out,parametersOnly = F)
  mres = MAP2(out)
  gamma0 = mres[[1]]
  #gamma0 = mean(samples[which(samples[,(ncol(samples)-1)]==max(samples[,(ncol(samples)-1)])),1:(ncol(samples)-3)])
  ssemin = -mres[[2]][2]
  
  rts <- matrix(q,nrow = n*tt,ncol = Th) - matrix(gamma0,nrow  = n*tt,ncol = Th,byrow = TRUE)
  rts[which(rts>0,arr.ind = TRUE)] <- 1
  rts[which(rts<=0,arr.ind = TRUE)] <- 0
  rtss <- matrix(rts,n*tt,nx*Th)
  rts0 <- cbind(matrix(1,n*tt,nx),rtss)
  
  xxx = cbind(yy_1*rts,xx*rts0)
  
  
  if(isTRUE(inittype1)){
    x1=cbind(xxx,cvs)
  }
  
  if(qr(xxx)$rank <ncol(xxx)){
    mx = DPMs03(y=y,delty0 =delty0,x=x,x1=cbind(x,cvs),cvs=cvs0,sdu=sdu,tt=tt,nn=nn)
    pars = mx$par
  }else{
    mx = DPMs03(y=y,delty0 =delty0,x=xxx,x1=x1,cvs=cvs0,sdu=sdu,tt=tt,nn=nn)
    
    pars = mx$par
    if(length(pars)>1){
      pars = mx$par[1:(length(mx$par)-3-ncol(x1))]
      nx = ifelse(is.null(x),0,ncol(x))
      nz = ifelse(is.null(cvs0),0,ncol(cvs0))
      names(pars) <- c(rep("y1",Th+1),rep("x",(Th+1)*nx),rep("cvs",nz))
    }
  }
  
  
  
  IC = matrix(0,3,Th*2)
  
  colnames(IC) <- rep(c("Lower","Upper"),Th)
  rownames(IC) <- c("90%","95%","99%")
  
  for (i in 1:Th) {
    IC[1,(2*i-1):(2*i)] = c(stats::quantile(samples[,i],0.05),stats::quantile(samples[,i],0.95))
    IC[2,(2*i-1):(2*i)] = c(stats::quantile(samples[,i],0.025),stats::quantile(samples[,i],0.975))
    IC[3,(2*i-1):(2*i)] = c(stats::quantile(samples[,i],0.005),stats::quantile(samples[,i],0.995))
  }
  
  
  jieguo = list(gamma= gamma0,coefs = pars,model = mx,mcmc = samples,IC =  IC)
  
  
  
  return(jieguo)
}