#'Data generate procedure function (One threshold).
#'@param tt Time period.
#'@param nn The number of individuals.
#'@param b1 The Coef of y_it-1;
#'@param c1 The Coef of x;
#'@param b2 The Coef of y_it-1 I(q>rt);
#'@param c2 The Coef of x I(q>rt);
#'@param aa The Coef of z, the explanatory variable without threshold effects;
#'@param db The external parameter of y;
#'@param dc The external parameter of x;
#'@param da The external parameter of z;
#'@param r0 The 1st threshold parameter;
#'@param r1 The 2nd threshold parameter;
#'@param sd1 The sd of uit.
#'@param sd2 sd2>sd1.
#'@return A list of data.
#'@author Hujie Bai.
#'@references Mine
#'@examples
#'# d1 = dgpcDT(5,500,b2 = 0, c2 = 0,aa=0,da=0)
#'@export
dgpcDT = function(tt,nn,b1=1,c1=1,b2=1,c2=1,aa=1,db=1,dc=1,da=1,r0=0.2,r1=0.5,sd1=2,sd2=4){
  TT = tt+1
  N = nn
  sz = TT*N
  qit = rnorm(sz,0.2)
  sit = rnorm(sz)
  zit = rnorm(sz)
  ei = rnorm(nn,2,3)
  ai = ei+colMeans(matrix(qit,nrow = TT))
  ai = matrix(ai,TT,N,byrow = TRUE)
  
  yit = matrix(0,TT,N)
  q = matrix(qit,TT,N)
  z = matrix(zit,TT,N)
  
  rt = r0+r1*sit
  regime2 = ifelse(q>rt,1,0)
  regime2 = matrix(regime2,TT,N)
  uit =matrix(rnorm(sz,sd=sd1),TT,N)
  uit1 = uit[-1,] - uit[-TT,]
  
  yit[1,] = ai[1,]
  for (i in 2:TT) {
    if(i==2){
      yit[i,] = db*matrix(1,1,N)+dc*(q[i,]-q[i-1,])+da*(z[i,]-z[i-1,])+rnorm(N,sd=sd2)+yit[i-1,]
    }else{
      yit[i,] = b1*(yit[i-1,]-yit[i-2,])+c1*(q[i,]-q[i-1,])+b2*((yit[i-1,])*(regime2[i,])-(yit[i-2,])*(regime2[i-1,]))+c2*((q[i,])*(regime2[i,])-(q[i-1,])*(regime2[i-1,]))+aa*(z[i,]-z[i-1,])+uit1[i-1,]+yit[i-1,]
      #yit[i,] = ai[i,]+b1*yit[i-1,]+c1*q[i,]+b2*yit[i-1,]*regime2[i,]+c2*q[i,]*regime2[i,]+aa*z[i,]+rnorm(N)
    }
  }
  
  return(list(y=as.vector(yit),q=qit,x=as.matrix(qit),z=as.matrix(zit),st = as.matrix(sit),tt=TT,nn=nn,re2 = regime2))
}





dgp2a = function(tt,nn){
  nb=5
  TT = tt+1
  N = nn
  sz = TT*N
  xx = matrix(0,sz,nb)
  xx[,1] = rnorm(sz)
  q = rnorm(sz)
  st = rnorm(sz)
  re1 =ifelse(q>(-0.5+0.5*st),1,0)
  regime1 = matrix(re1,TT,nn)
  re2 =ifelse(q>(0.5*st),1,0)
  regime2 = matrix(re2,TT,nn)
  xx[,2] = xx[,1]*re1
  xx[,3] = xx[,1]*re2
  zit = rnorm(sz)
  z = matrix(zit,TT,N)
  
  yit = matrix(0,TT,N)
  ai = rnorm(nn,2,3)
  ai = matrix(ai,TT,N,byrow = TRUE)
  uit =matrix(rnorm(sz,sd=2),TT,N)
  uit1 = uit[-1,] - uit[-TT,]
  yit[1,] = ai[1,]
  
  xit = matrix(xx,TT)[-1,] - matrix(xx,TT)[-TT,]
  
  for (i in 2:TT) {
    if(i==2){
      yit[i,] = 0.5*matrix(1,1,N)+0.5*xit[i-1,1:50]+0.5*(z[i,]-z[i-1,])+yit[i-1,]+rnorm(N,sd=4)
    }else{
      yit[i,] = 2*(yit[i-1,]-yit[i-2,])+2*(yit[i-1,]*regime1[i,]-yit[i-2,]*regime1[i-1,])+2*(yit[i-1,]*regime2[i,]-yit[i-2,]*regime2[i-1,])+2*xit[i-1,1:50]+2*xit[i-1,51:100]+2*xit[i-1,101:150]+2*(z[i,]-z[i-1,])+yit[i-1,]+uit1[i-1,]
      #yit[i,] = ai[i,]+b1*yit[i-1,]+c1*q[i,]+b2*yit[i-1,]*regime2[i,]+c2*q[i,]*regime2[i,]+aa*z[i,]+rnorm(N)
    }
  }
  
  # xx[,4] = matrix(rbind(rep(0,nn),matrix(yit,TT,nn)[-TT,]),ncol = 1)*re1
  # xx[,5] = matrix(rbind(rep(0,nn),matrix(yit,TT,nn)[-TT,]),ncol = 1)*re2
  return(list(y=as.vector(yit),q = q,st=as.matrix(st),x = as.matrix(xx[,1]),cvs = as.matrix(zit),tt =TT,nn=nn))
}

dgp2b = function(tt,nn){
  nb=5
  TT = tt+1
  N = nn
  sz = TT*N
  xx = matrix(0,sz,nb)
  xx[,1] = rnorm(sz)
  q = rnorm(sz)
  st = rnorm(sz)
  re1 =ifelse(q>(-0.5+0.5*st),1,0)
  regime1 = matrix(re1,TT,nn)
  re2 =ifelse(q>(0.5*st),1,0)
  regime2 = matrix(re2,TT,nn)
  xx[,2] = xx[,1]*re1
  xx[,3] = xx[,1]*re2
  zit = rnorm(sz)
  z = matrix(zit,TT,N)
  
  yit = matrix(0,TT,N)
  ai = rnorm(nn,2,3)
  ai = matrix(ai,TT,N,byrow = TRUE)
  uit =matrix(rnorm(sz,sd=2),TT,N)
  uit1 = uit[-1,] - uit[-TT,]
  yit[1,] = ai[1,]
  
  xit = matrix(xx,TT)[-1,] - matrix(xx,TT)[-TT,]
  
  for (i in 2:TT) {
    if(i==2){
      yit[i,] = 0.5*matrix(1,1,N)+0.5*xit[i-1,1:50]+yit[i-1,]+rnorm(N,sd=4)
    }else{
      yit[i,] = 2*(yit[i-1,]-yit[i-2,])+2*(yit[i-1,]*regime1[i,]-yit[i-2,]*regime1[i-1,])+2*(yit[i-1,]*regime2[i,]-yit[i-2,]*regime2[i-1,])+2*xit[i-1,1:50]+2*xit[i-1,51:100]+2*xit[i-1,101:150]+yit[i-1,]+uit1[i-1,]
      #yit[i,] = ai[i,]+b1*yit[i-1,]+c1*q[i,]+b2*yit[i-1,]*regime2[i,]+c2*q[i,]*regime2[i,]+aa*z[i,]+rnorm(N)
    }
  }
  
  # xx[,4] = matrix(rbind(rep(0,nn),matrix(yit,TT,nn)[-TT,]),ncol = 1)*re1
  # xx[,5] = matrix(rbind(rep(0,nn),matrix(yit,TT,nn)[-TT,]),ncol = 1)*re2
  return(list(y=as.vector(yit),q = q,st=as.matrix(st),x = as.matrix(xx[,1]),cvs = NULL,tt =TT,nn=nn))
}

dgp2c = function(tt,nn){
  nb=5
  TT = tt+1
  N = nn
  sz = TT*N
  xx = matrix(0,sz,nb)
  xx[,1] = rnorm(sz)
  q = rnorm(sz)
  st = rnorm(sz)
  re1 =ifelse(q>(-0.5+0.5*st),1,0)
  regime1 = matrix(re1,TT,nn)
  re2 =ifelse(q>(0.5*st),1,0)
  regime2 = matrix(re2,TT,nn)
  xx[,2] = xx[,1]*re1
  xx[,3] = xx[,1]*re2
  zit = rnorm(sz)
  z = matrix(zit,TT,N)
  
  yit = matrix(0,TT,N)
  ai = rnorm(nn,2,3)
  ai = matrix(ai,TT,N,byrow = TRUE)
  uit =matrix(rnorm(sz,sd=2),TT,N)
  uit1 = uit[-1,] - uit[-TT,]
  yit[1,] = ai[1,]
  
  xit = matrix(xx,TT)[-1,] - matrix(xx,TT)[-TT,]
  
  for (i in 2:TT) {
    if(i==2){
      yit[i,] = 0.5*matrix(1,1,N)+yit[i-1,]+rnorm(N,sd=4)
    }else{
      yit[i,] = 2*(yit[i-1,]-yit[i-2,])+2*(yit[i-1,]*regime1[i,]-yit[i-2,]*regime1[i-1,])+2*(yit[i-1,]*regime2[i,]-yit[i-2,]*regime2[i-1,])+yit[i-1,]+uit1[i-1,]
      #yit[i,] = ai[i,]+b1*yit[i-1,]+c1*q[i,]+b2*yit[i-1,]*regime2[i,]+c2*q[i,]*regime2[i,]+aa*z[i,]+rnorm(N)
    }
  }
  
  # xx[,4] = matrix(rbind(rep(0,nn),matrix(yit,TT,nn)[-TT,]),ncol = 1)*re1
  # xx[,5] = matrix(rbind(rep(0,nn),matrix(yit,TT,nn)[-TT,]),ncol = 1)*re2
  return(list(y=as.vector(yit),q = q,st=as.matrix(st),x = NULL,cvs = NULL,tt =TT,nn=nn))
}